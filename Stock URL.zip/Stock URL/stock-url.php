<?php
/**
 * Plugin Name:       Stock URL
 * Plugin URI:        https://example.com
 * Description:       Fetch API and store to wordpress.
 * Version:           1.0.0
 * Author:            Subrata Goswami
 * Author URI:        https://test.example.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/my-plugin/
 * Text Domain:       stock-url
 * Domain Path:       /languages
 */

register_activation_hook(__FILE__, 'create_required_table');

function create_required_table(){
	global $wpdb;

	$charset_collate = $wpdb->get_charset_collate();
	$table_name = $wpdb->prefix . 'stockdata';
	$sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        low varchar(255) NOT NULL,
        sdate datetime NOT NULL,
        high varchar(255) NOT NULL,
        open varchar(255) NOT NULL,
        close varchar(255) NOT NULL,
        volume_btc varchar(255) NOT NULL,
        volume_usd varchar(255) NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";
	// print_r($sql);die;

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );

	//get api data
	$api_url = 'https://api.npoint.io/5ac670dd66db71dffa1f';
	$request = wp_remote_get($api_url);
	$data = json_decode( wp_remote_retrieve_body( $request ) );
	foreach($data as $line) {		
        $wpdb->insert( $table_name, array(
            'low' => $line->low, 
            'sdate' => $line->date, 
            'high' => $line->high,
            'open' => $line->open, 
            'close' => $line->close,
            'volume_btc' => $line->volume_btc, 
            'volume_usd' => $line->volume_usd
            )
        );
	}

	wp_insert_post([
	  'post_title'    => 'Display Data',
	  'post_content'  => '',
	  'post_status'   => 'publish',
	  'post_type'=> 'page',
	  'post_author'   => 1,
	]);
}

// add_action('init', 'create_required_table');

add_action( 'wp_enqueue_scripts', 'load_all_scripts' );

function load_all_scripts(){

	 wp_enqueue_script(
        'chart-js-min',
        plugin_dir_url(__FILE__) . '/js/chartjs/canvasjs.stock.min.js',
        array( 'jquery' )
    );

	wp_localize_script('chart-js-min','chartObj',[
		'stock_api_endpoint' => home_url('wp-json/stock-data/v1/data')
	]) ;
}


add_filter( 'page_template', 'stock_page_template' );
function stock_page_template( $page_template )
{
	
    if ( is_page( 'display-data' ) ) {
        $page_template = dirname( __FILE__ ) . '/page-chart.php';
    }
    return $page_template;
}

function easy_post_api_init() {

    $namespace = 'stock-data/v1';
    register_rest_route( $namespace, '/data/', array(
        'methods' => 'GET',
        'callback' => 'callback_stock_data',
    ) );

}
add_action( 'rest_api_init', 'easy_post_api_init' );

function callback_stock_data( WP_REST_Request $request ){
	global $wpdb;
	$table_name = $wpdb->prefix . 'stockdata';
	$results = $wpdb->get_results( "SELECT sdate as date, open, high, low,  close, volume_btc, volume_usd FROM $table_name"); 
	$json_data = json_encode($results);



	return json_decode($json_data);
}

//on plugin deactivation
register_deactivation_hook(__FILE__, 'deactivation_event');

function deactivation_event(){
	global $wpdb;
	$table_name = $wpdb->prefix . 'stockdata';
    $wpdb->query( "DROP TABLE IF EXISTS $table_name" );
}

